package com.system.mapper;

import com.system.entity.RoleMenu;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Byterain
 * @since 2022-11-29
 */
public interface RoleMenuMapper extends BaseMapper<RoleMenu> {

}
