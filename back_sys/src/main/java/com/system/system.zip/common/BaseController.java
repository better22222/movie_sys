package com.system.common;
public class BaseController {
//每个控制器用到的对象
}